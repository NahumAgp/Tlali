#!/usr/bin/env python3
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


ESQUEMA = """
CREATE TABLE IF NOT EXISTS telemetria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recibido_utc TEXT NOT NULL,
    nodo TEXT NOT NULL,
    tipo TEXT NOT NULL,
    secuencia INTEGER NOT NULL,
    uptime_ms INTEGER NOT NULL,
    trama_json TEXT NOT NULL,
    estado_envio TEXT NOT NULL DEFAULT 'pendiente'
        CHECK (estado_envio IN ('pendiente', 'enviando', 'enviado', 'error')),
    intentos_envio INTEGER NOT NULL DEFAULT 0,
    enviado_utc TEXT,
    ultimo_error TEXT,
    UNIQUE (nodo, secuencia, uptime_ms)
);

CREATE INDEX IF NOT EXISTS idx_telemetria_estado_id
ON telemetria (estado_envio, id);

CREATE INDEX IF NOT EXISTS idx_telemetria_nodo_fecha
ON telemetria (nodo, recibido_utc);
"""


def fecha_utc():
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def validar_trama(trama):
    if not isinstance(trama, dict):
        raise ValueError("La trama debe ser un objeto JSON")

    requeridos = {
        "node": str,
        "type": str,
        "seq": int,
        "uptimeMs": int,
        "data": dict,
        "valid": dict,
    }
    for campo, tipo in requeridos.items():
        if campo not in trama:
            raise ValueError(f"Falta el campo obligatorio {campo}")
        if not isinstance(trama[campo], tipo):
            raise ValueError(f"El campo {campo} tiene un tipo incorrecto")


class AlmacenLocal:
    def __init__(self, ruta):
        self.ruta = Path(ruta).expanduser().resolve()
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        self.conexion = sqlite3.connect(self.ruta, timeout=10)
        self.conexion.execute("PRAGMA journal_mode=WAL")
        self.conexion.execute("PRAGMA synchronous=NORMAL")
        self.conexion.execute("PRAGMA foreign_keys=ON")
        self.conexion.executescript(ESQUEMA)
        self.conexion.commit()

    def guardar(self, trama):
        validar_trama(trama)
        trama_json = json.dumps(
            trama,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        cursor = self.conexion.execute(
            """
            INSERT OR IGNORE INTO telemetria (
                recibido_utc,
                nodo,
                tipo,
                secuencia,
                uptime_ms,
                trama_json
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                fecha_utc(),
                trama["node"],
                trama["type"],
                trama["seq"],
                trama["uptimeMs"],
                trama_json,
            ),
        )
        self.conexion.commit()
        insertada = cursor.rowcount == 1

        if insertada:
            return cursor.lastrowid, True

        fila = self.conexion.execute(
            """
            SELECT id
            FROM telemetria
            WHERE nodo = ? AND secuencia = ? AND uptime_ms = ?
            """,
            (trama["node"], trama["seq"], trama["uptimeMs"]),
        ).fetchone()
        return (fila[0] if fila else None), False

    def resumen(self):
        total = self.conexion.execute(
            "SELECT COUNT(*) FROM telemetria"
        ).fetchone()[0]
        pendientes = self.conexion.execute(
            """
            SELECT COUNT(*)
            FROM telemetria
            WHERE estado_envio IN ('pendiente', 'error')
            """
        ).fetchone()[0]
        por_nodo = self.conexion.execute(
            """
            SELECT nodo, COUNT(*), MAX(recibido_utc)
            FROM telemetria
            GROUP BY nodo
            ORDER BY nodo
            """
        ).fetchall()
        return total, pendientes, por_nodo

    def ultimas(self, limite=10):
        return self.conexion.execute(
            """
            SELECT
                id,
                recibido_utc,
                nodo,
                tipo,
                secuencia,
                estado_envio,
                trama_json
            FROM telemetria
            ORDER BY id DESC
            LIMIT ?
            """,
            (limite,),
        ).fetchall()

    def cerrar(self):
        self.conexion.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.cerrar()
